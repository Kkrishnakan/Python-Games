# Rock_Paper_Scissors_Games_with_Python
This is a classic "Rock, Paper, Scissors" game with some ASCII aesthetics. After the welcome message, the game asks you to choose between the three choices. Then it let the computer choose its choice. The yours and the computer's choices are compared, a message appears to let you know the result, then the game asks if you want to play it again. Once you choose to quit the game, a summary message appear with the number of games you have played and the results of wins and looses.

The game can still be developed for more excitements, such as more (simple) graphics to represent the choices or the summarized results.

The highlight of this game, however, is the summary message. It will always give the user a grammartically-correct message, doesn't matter how many times he/she won, lost, or drew with the computer.

Credit: This program (game) is a modification of a Python program found in Angela Yu's "100 Days of Code: The Complete Python Pro Bootcamp" on Udemy. You can go to the course's page by clicking the following link (not a ref. link): https://www.udemy.com/course/100-days-of-code/
