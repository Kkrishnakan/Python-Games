# Introduction
https://mp.weixin.qq.com/s/jpIJWXrW6O35cfELeplOtQ

# Usage
- pip install -r requirements.txt
- python Game7.py

# Game Display
![giphy](effect/running.gif)

# Python Version[Tested]
- Python3.6

# Packages
- pygame
- random
- sys
- time
- math