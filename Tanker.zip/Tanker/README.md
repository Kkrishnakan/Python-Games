# Introduction
https://mp.weixin.qq.com/s/KuktB_f1vxZCNIAHaaXdsQ

# Usage
- pip install -r requirements.txt
- python Game5.py

# Game Display
![giphy](effect/running.gif)

# Python Version[Tested]
- Python3.6

# Packages
- pygame
- random
- sys