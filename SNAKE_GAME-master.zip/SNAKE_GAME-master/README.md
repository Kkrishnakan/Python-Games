# SNAKE_GAME
First game written in Python using PyGame library. Simple Snake game with some points counter, obsticles, power-ups and hero transformation.
Game was created as final semester project for Introduction to Computer Science.

## Game Screen Shots

<img src="https://github.com/SkalskiP/SNAKE_GAME/blob/master/SCREENS/Main_Screen.PNG" alt="Main Screen">
<img src="https://github.com/SkalskiP/SNAKE_GAME/blob/master/SCREENS/Game_Rules_1.PNG" alt="Game Rules Screen 1">
<img src="https://github.com/SkalskiP/SNAKE_GAME/blob/master/SCREENS/Game_Rules_2.PNG" alt="Game Rules Screen 2">
<img src="https://github.com/SkalskiP/SNAKE_GAME/blob/master/SCREENS/Game_Board_1.PNG" alt="Game Board Screen 1">
<img src="https://github.com/SkalskiP/SNAKE_GAME/blob/master/SCREENS/Game_Board_3.PNG" alt="Game Board Screen 2">
<img src="https://github.com/SkalskiP/SNAKE_GAME/blob/master/SCREENS/Game_Over_Screen.PNG" alt="Game Over Screen">
